# CrafterParty Ressourcenpack

## Struktur
- `assets/minecraft/models/item/paper.json` – Overrides für die 5 Würfel (Custom Model Data 2001–2005)
- `assets/minecraft/models/item/carved_pumpkin.json` – Overrides für die 8 Skin-Hüte (1001–1008)
- `assets/crafterparty/models/item/` – Eigene Modelle (mit Blockbench erstellen/ersetzen)
- `assets/crafterparty/textures/item/` – Hier die PNG-Texturen ablegen:
  `dice_standard.png`, `dice_bronze.png`, `dice_silver.png`, `dice_gold.png`, `dice_chaos.png`
  sowie je eine Textur pro Skin-Modell.

## Wichtig
- **Keine geschützten Fremd-Assets** (z. B. Nintendo/Mario-Texturen) verwenden –
  gestaltet eigene Charaktere im gewünschten Stil.
- Pack als ZIP packen (Inhalt: `pack.mcmeta` + `assets/` auf oberster Ebene),
  auf einen HTTP-Server/CDN laden und die URL + SHA1 in der `config.yml` unter
  `resourcepack.url` eintragen.
- `pack_format` an eure Zielversion anpassen.

## Server-seitige Verteilung
Optional in der `server.properties` der Spielserver:
```
resource-pack=https://dein-cdn.example/crafterparty-pack.zip
require-resource-pack=true
```
